package com.william.soal2.model

data class Question(
    val question: String,
    val options: List<String>,
    val correctAnswer: Int
)

data class AnswerResult(
    val question: Question,
    val selectedAnswer: Int
)