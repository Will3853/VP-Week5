package com.william.soal1.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.william.soal1.Greeting
import com.william.soal1.model.Expense
import com.william.soal1.ui.theme.Soal1Theme
import com.william.soal1.viewmodel.ExpenseViewModel

@Composable
fun Soal1(viewModel: ExpenseViewModel = viewModel()) {
    val expenseList by viewModel.expenseList.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val totalExpense = expenseList.sumOf { it.amount }
    var expenseName by rememberSaveable { mutableStateOf("") }
    var editingIndex by rememberSaveable { mutableIntStateOf(-1) }
    Box(Modifier.fillMaxSize().padding(20.dp)){
        Column() {
            Spacer(modifier = Modifier.height(20.dp))
            Text("Expense", fontWeight = FontWeight.Bold, fontSize = 24.sp)
            Text("Total Expense: $totalExpense", fontSize = 14.sp)
            OutlinedTextField(
                value = uiState.name,
                onValueChange = { viewModel.onNameChange(it) },
                placeholder = { Text("Expense Name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedBorderColor = Color.LightGray,
                    focusedBorderColor = Color.Gray,
                    unfocusedContainerColor = Color.White,
                    focusedContainerColor = Color.White,
                    unfocusedTextColor = Color.Black,
                    focusedTextColor = Color.Black,
                    unfocusedLabelColor = Color.Gray,
                    focusedLabelColor = Color.Gray
                )
            )

            Row(Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = uiState.expense,
                    onValueChange = { viewModel.onExpenseChange(it) },
                    label = { Text("Amount of Expense") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = Color.LightGray,
                        focusedBorderColor = Color.Gray,
                        unfocusedContainerColor = Color.White,
                        focusedContainerColor = Color.White,
                        unfocusedTextColor = Color.Black,
                        focusedTextColor = Color.Black,
                        unfocusedLabelColor = Color.Gray,
                        focusedLabelColor = Color.Gray
                    )
                )
                Button(
                    onClick = {
                        if (editingIndex == -1) {
                            viewModel.addExpense()
                        } else {
                            val name = uiState.name
                            val amount = uiState.expense.toIntOrNull()

                            if (name.isNotBlank() && amount != null && amount > 0) {
                                viewModel.updateExpense(
                                    editingIndex,
                                    Expense(name, amount)
                                )

                                editingIndex = -1
                                viewModel.onNameChange("")
                                viewModel.onExpenseChange("")
                            }
                        }
                    },
                    shape = CircleShape,
                    modifier = Modifier.size(50.dp),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFD7D7D7)
                    )
                ) {
                    Text(
                        text = "+",
                        color = Color.Gray
                    )
                }
            }
            Spacer(Modifier.height(20.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(expenseList) { index, expense ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x6691BEFF))
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    expense.name,
                                    fontSize = 16.sp
                                )

                                Text(
                                    "Amount: ${expense.amount}",
                                    fontSize = 12.sp
                                )
                            }

                            Row {
                                IconButton(
                                    onClick = {
                                            editingIndex = index
                                            viewModel.onNameChange(expense.name)
                                            viewModel.onExpenseChange(expense.amount.toString())
                                    }
                                ) {
                                    Icon(
                                        Icons.Filled.Edit,
                                        contentDescription = "Edit",
                                        tint = Color.Yellow
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        viewModel.deleteExpense(index)
                                    }
                                ) {
                                    Icon(
                                        Icons.Filled.Delete,
                                        contentDescription = "Delete",
                                        tint = Color.Red
                                    )
                                }
                            }
                        }
                    }
                }
            }

        }
    }
}


@Preview(showBackground = true, showSystemUi = true)
@Composable
fun GreetingPreview() {
    Soal1Theme {
        Soal1()
    }
}