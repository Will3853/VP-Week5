package com.william.soal1.data

import com.william.soal1.model.Expense
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

object ExpenseRepo {
    private val _expense = MutableStateFlow<List<Expense>>(emptyList())
    val expenseList: StateFlow<List<Expense>> = _expense.asStateFlow()
    fun add(booking: Expense) {
        _expense.update { it + booking }
    }
    fun deleteAt(index: Int) {
        _expense.update { list->
            if (index in list.indices) list.toMutableList().apply { removeAt(index) }
            else list
        }
    }
    fun updateAll(expenses: List<Expense>) {
        _expense.value = expenses
    }
}