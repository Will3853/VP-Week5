package com.william.soal1.model

data class Expense (
    val name: String,
    val amount: Int
)