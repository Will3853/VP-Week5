package com.william.soal2.viewmodel

import androidx.lifecycle.ViewModel
import com.william.soal2.data.QuestionRepository
import com.william.soal2.model.AnswerResult
import com.william.soal2.model.Question
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class QuestionViewModel : ViewModel() {
    private val _questions = MutableStateFlow(QuestionRepository.getRandomQuestions())
    val questions = _questions.asStateFlow()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex = _currentIndex.asStateFlow()

    private val _answers = MutableStateFlow<List<AnswerResult>>(emptyList())
    val answers = _answers.asStateFlow()

    private val _isFinished = MutableStateFlow(false)
    val isFinished = _isFinished.asStateFlow()

    fun answerQuestion(selectedAnswer: Int) {
        if (_isFinished.value) return

        val question = _questions.value[_currentIndex.value]

        _answers.value = _answers.value + AnswerResult(question, selectedAnswer)

        if (_currentIndex.value == _questions.value.lastIndex) {
            _isFinished.value = true
        } else {
            _currentIndex.value++
        }
    }
    fun getScore(): Int {
        return _answers.value.count {
            it.selectedAnswer == it.question.correctAnswer
        }
    }
    fun restartQuiz() {
        _questions.value = QuestionRepository.getRandomQuestions()
        _currentIndex.value = 0
        _answers.value = emptyList()
        _isFinished.value = false
    }
}
