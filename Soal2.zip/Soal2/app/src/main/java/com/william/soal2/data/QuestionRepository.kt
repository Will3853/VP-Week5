package com.william.soal2.data
import com.william.soal2.model.Question

object QuestionRepository{
    val questions = listOf(
        Question("Ibu kota Indonesia?", listOf("Surabaya", "Bandung", "Jakarta", "Medan"), 2), // Soal 1.
        Question("Planet terdekat dengan Matahari?", listOf("Venus", "Merkurius", "Mars", "Bumi"), 1), // Soal 2.
        Question("Hasil dari 5 x 6?", listOf("11", "25", "30", "35"), 2), // Soal 3.
        Question("Bahasa resmi Indonesia?", listOf("Jawa", "Inggris", "Sunda", "Indonesia"), 3), // Soal 4.
        Question("Hewan yang dikenal sebagai raja hutan?", listOf("Harimau", "Singa", "Gajah", "Serigala"), 1), // Soal 5.
    )
    fun getRandomQuestions(): List<Question> {
        return questions.shuffled().take(3)
    }
}
