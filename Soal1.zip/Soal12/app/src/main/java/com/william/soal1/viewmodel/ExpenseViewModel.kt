
package com.william.soal1.viewmodel

import androidx.lifecycle.ViewModel
import com.william.soal1.data.ExpenseRepo
import com.william.soal1.model.Expense
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class ExpenseUiState(
    val name: String = "",
    val expense: String = "",
    val showError: Boolean = false
) {
    val nameError: Boolean
        get() = showError && name.isBlank()

    val expenseError: Boolean
        get() = showError && !isValidAmount(expense)
}

fun isValidAmount(amount: String): Boolean {
    val number = amount.toIntOrNull()

    if (number == null) {
        return false
    }

    return number > 0
}

class ExpenseViewModel(
    private val expenseRepository: ExpenseRepo = ExpenseRepo
) : ViewModel() {

    private val _uiState =
        MutableStateFlow(ExpenseUiState())

    val uiState: StateFlow<ExpenseUiState> =
        _uiState.asStateFlow()

    val expenseList = expenseRepository.expenseList

    fun onNameChange(name: String) {
        _uiState.update {
            it.copy(name = name)
        }
    }

    fun onExpenseChange(expense: String) {
        _uiState.update {
            it.copy(expense = expense)
        }
    }

    fun addExpense() {
        val state = _uiState.value

        _uiState.update {
            it.copy(showError = true)
        }

        if (state.name.isBlank() ||
            !isValidAmount(state.expense)
        ) {
            return
        }

        expenseRepository.add(
            Expense(
                name = state.name,
                amount = state.expense.toInt()
            )
        )

        _uiState.value = ExpenseUiState()
    }
    fun deleteExpense(index: Int) {
        expenseRepository.deleteAt(index)
    }
    fun updateExpense(index: Int, expense: Expense) {
        val currentList = expenseRepository.expenseList.value.toMutableList()

        if (index in currentList.indices) {
            currentList[index] = expense
            expenseRepository.updateAll(currentList)
        }
    }
}
