package com.william.soal2.screen

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.william.soal2.viewmodel.QuestionViewModel
enum class QuizPage {
    QUIZ,
    RESULT
}

@Composable
fun QuizScreen(
    viewModel: QuestionViewModel = viewModel()
) {
    var currentPage by remember {
        mutableStateOf(QuizPage.QUIZ)
    }

    val questions by viewModel.questions.collectAsState()
    val currentIndex by viewModel.currentIndex.collectAsState()
    val answers by viewModel.answers.collectAsState()

    when (currentPage) {
        QuizPage.QUIZ -> {
            if (questions.isNotEmpty()) {
                val question = questions[currentIndex]

                var selectedOption by remember(currentIndex) {
                    mutableStateOf<Int?>(null)
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Question ${currentIndex + 1} of ${questions.size}",
                        fontSize = 24.sp
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = question.question,
                        fontSize = 18.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    question.options.forEachIndexed { index, option ->
                        Button(
                            onClick = {
                                selectedOption = index
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .height(40.dp),
                            shape = RoundedCornerShape(50),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedOption == index)
                                    Color(0xFF53628F)
                                else
                                    Color(0xFFDDE2F8),
                                contentColor = if (selectedOption == index)
                                    Color.White
                                else
                                    Color(0xFF30364F)
                            ),
                            contentPadding = PaddingValues(16.dp, 0.dp)
                        ) {
                            Text(
                                text = option,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val lastQuestion = currentIndex == questions.lastIndex

                            viewModel.answerQuestion(selectedOption!!)

                            if (lastQuestion) {
                                currentPage = QuizPage.RESULT
                            }
                        },
                        enabled = selectedOption != null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp),
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF53628F),
                            disabledContainerColor = Color(0xFFE5E5EA),
                            contentColor = Color.White,
                            disabledContentColor = Color(0xFFAAAAAA)
                        )
                    ) {
                        Text("Next", fontSize = 12.sp)
                    }
                }
            }
        }

        QuizPage.RESULT -> {
            val wrongAnswers = answers.filter {
                it.selectedAnswer != it.question.correctAnswer
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("Quiz Finished!", fontSize = 30.sp)

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Your Score: ${viewModel.getScore()} / ${questions.size}",
                    fontSize = 22.sp
                )
                Spacer(modifier = Modifier.height(24.dp))
                Text("Incorrect Answers", fontSize = 20.sp)
                Spacer(modifier = Modifier.height(12.dp))

                if (wrongAnswers.isEmpty()) {
                    Text("Perfect! No wr0ng answers.", color = Color.Blue)
                } else {
                    wrongAnswers.forEach { result ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(4.dp)
                            ) {
                                Text(result.question.question)
                                Text(
                                    text = "Your answer: ${result.question.options[result.selectedAnswer]}",
                                    color = Color.Red
                                )

                                Text(
                                    text = "Correct answer: ${result.question.options[result.question.correctAnswer]}",
                                    color = Color.Blue
                                )
                                Box(modifier = Modifier.height(1.dp).fillMaxWidth().background(Color(
                                    0xFF9D9D9D
                                )
                                ))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        viewModel.restartQuiz()
                        currentPage = QuizPage.QUIZ
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Restart Quiz")
                }
            }
        }
    }
}

@SuppressLint("ViewModelConstructorInComposable")
@Preview(showBackground = true, showSystemUi = true)
@Composable
fun QuizScreenPreview() {
    QuizScreen(
        viewModel = QuestionViewModel(),
    )
}